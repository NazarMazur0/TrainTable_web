<php?
function load_stylesheets(){
    wp_register_style('style', get_template_directory_uri().'/css/style.cs', array(), 1, 'all' );
    wp_enqueue_style('style');

    wp_register_style('SnackBar', get_template_directory_uri().'/css/js-snackbar.css', array(), 1, 'all' );
    wp_enqueue_style('SnackBar');
}
add_action('wp_enqueue_script','load_stylesheets');


function addjs(){
  wp_register_script('main', get_template_directory_uri().'/js/main.js', array(), 1, 1, 1 );
  wp_enqueue_script('main');

  wp_register_script('routes', get_template_directory_uri().'/js/routes.json', array(), 1, 1, 1 );
  wp_enqueue_script('routes');

  wp_register_script('match', get_template_directory_uri().'/js/match.js', array(), 1, 1, 1 );
  wp_enqueue_script('match');


  wp_register_script('stop', get_template_directory_uri().'/js/stop.js', array(), 1, 1, 1 );
  wp_enqueue_script('stop');

  wp_register_script('js-snackbar', get_template_directory_uri().'/js/js-snackbar.js', array(), 1, 1, 1 );
  wp_enqueue_script('js-snackbar');

}
?>
