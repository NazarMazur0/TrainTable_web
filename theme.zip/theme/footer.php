


  <!-- Footer -->
  <footer class="bg-dark text-center text-white" id="about">
    <!-- Grid container -->
    <div class="container p-4">
      <!-- Section: Social media -->
      <section class="mb-4">
        <a class="btn btn-outline-light btn-floating m-1" href="tel:+380960920894" role="button">
          <i class="fas fa-phone"></i>
      </a>
        <a class="btn btn-outline-light btn-floating m-1" href="mailto:nazar.mazur@ukr.net" role="button">
          <i class="fas fa-at"></i>
      </a>
        <a class="btn btn-outline-light btn-floating m-1" href="https://t.me/nazar4367" role="button">
          <i class="fab fa-telegram"></i>
        </a>
        <a class="btn btn-outline-light btn-floating m-1" href="https://github.com/NazarMazur0?tab=packages" role="button">
          <i class="fab fa-github"></i>
      </a>
      </section>
      <!-- Section: Social media -->



      <!-- Section: Text -->
      <section class="mb-4">
        <p>
        Дякую за перегляд!
        </p>
      </section>
      <!-- Section: Text -->

      <!-- Section: Links -->
      <section class="">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4 mb-md-0">

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Використані технології</h5>

            <ul class="list-unstyled mb-0">
              <li>
                <a href="https://jquery.com" class="text-info">jQuery</a>
              </li>
              <li>
                <a href="https://getbootstrap.com" class="text-info">Bootstrap</a>
              </li>
              <li>
                <a href="https://github.com/mickelsonmichael/js-snackbar" class="text-info">JS-Snackbar</a>
              </li>
              <li>
                <a href="https://fontawesome.com" class="text-info">Font Awesome</a>
              </li>
              <li>
                <a href="https://fonts.google.com" class="text-info">Google Fonts</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->

          <!--Grid column-->

          <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </section>
      <!-- Section: Links -->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      ©Nazar Mazur 2022
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script type="text/javascript"  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <?php wp_footer();?>

</body>
</html>
