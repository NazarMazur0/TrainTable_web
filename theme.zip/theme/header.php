<!DOCTYPE html>
<html lang="en">
<head>

      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Document</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css" rel="stylesheet"/>
    <?php wp_head();?>

</head>
<body >
  <header id="home">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-dark " style="position: fixed; z-index:100;top:0; left:0; width:100%;">
    <div class="container-fluid ">
      <button
        class="navbar-toggler"
        type="button"
        data-mdb-toggle="collapse"
        data-mdb-target="#navbarExample01"
        aria-controls="navbarExample01"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse " id="navbarExample01">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item active">
            <a class="nav-link text-light" aria-current="page" href="#home">Home <i class="bi bi-house"></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="#features">Features <i class="bi bi-card-list"></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="#search_link">Search<i class="bi bi-binoculars-fill"></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="#about">About<i class="bi bi-file-earmark-person-fill"></i></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Navbar -->

  <!-- Background image -->
  <div
    class="p-5 text-center rounded bg-image"
    style="
      background-image: url('http://192.168.56.10/wp-content/uploads/2022/05/train_station-min.jpg');
      height: 800px;
      width: 99%;
      position: relative;
      margin: auto;
      margin-top: 5%;
    "
  >
    <div class="mask" style="background-color: rgba(0, 0, 0, 0.6);">
      <div class="d-flex justify-content-center align-items-center h-100" style="position: sticky; margin-top: 10%;">
        <div class="text-white">
          <h1 class="mb-3">
            Train Table
          </h1>
          <h4 class="mb-3">
            Розклад поїздів онлайн
          </h4>
          <a class="btn btn-outline-light btn-lg" href="#search_link" role="button">
            Почати
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- Background image -->
</header>
