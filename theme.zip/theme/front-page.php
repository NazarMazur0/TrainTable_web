<?php get_header(); ?>


<div id="mainBody">

<div class="container" id="features" style="margin-top:50%;">


  <div class="row">
    <div class="col-md12">

      <div id="carouselExampleCaptions" class="carousel slide" data-mdb-ride="carousel">
  <div class="carousel-indicators">
    <button
      type="button"
      data-mdb-target="#carouselExampleCaptions"
      data-mdb-slide-to="0"
      class="active"
      aria-current="true"
      aria-label="Slide 1"
    ></button>
    <button
      type="button"
      data-mdb-target="#carouselExampleCaptions"
      data-mdb-slide-to="1"
      aria-label="Slide 2"
    ></button>
    <button
      type="button"
      data-mdb-target="#carouselExampleCaptions"
      data-mdb-slide-to="2"
      aria-label="Slide 3"
    ></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active ">
      <img src="http://192.168.56.10/wp-content/uploads/2022/05/kozatyn_station.jpg" class="d-block  rounded-5" alt="Wild Landscape"/>
      <div class="carousel-caption d-none d-md-block text-info">
        <h5>Козятин</h5>

      </div>
    </div>
    <div class="carousel-item ">
      <img src="http://192.168.56.10/wp-content/uploads/2022/05/zhmerynka_station.jpg" class="d-block rounded-5" alt="Camera"/>
      <div class="carousel-caption d-none d-md-block text-info">
        <h5>Жмеринка</h5>

      </div>
    </div>
    <div class="carousel-item ">
      <img src="http://192.168.56.10/wp-content/uploads/2022/05/lviv_station-1.png" class="d-block rounded-5" alt="Exotic Fruits"/>
      <div class="carousel-caption d-none d-md-block text-info">
        <h5>Львів</h5>

      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-mdb-target="#carouselExampleCaptions" data-mdb-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-mdb-target="#carouselExampleCaptions" data-mdb-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

    </div>
  </div>



  <div class="row">
    <div class="col-md12">

      <div class="container position-relative mw-100   border rounded border-5 p-5 bg-light" id="featuresText"> <h2>Цей сайт допоможе отримати інформацію про розклад руху поїздів онлайн. Все що вам потрібно - це знати з якого міста в яке вам потрібно дістатися , або номер конкретного поїзда.</h2></div>


    </div>
  </div>

</div>

<a href="" id="search_link"></a>
<section id="search">
  <div class="container " >

    <div class="row" id="list_row">
      <div class="col">
        <ul class="list-group" id="list">

        </ul>
      </div>
    </div>

  <br>

    <div class="row" id="row_cities">
      <div class="col">
        <div class="mb-3">
          <label for="cityFrom" class="form-label text-white text"><h3>Пункт відправлення <i class="bi bi-arrow-right-circle-fill text-primary"></i></h3></label>
          <input type="city" class="form-control edit" id="cityFrom" aria-describedby="emailHelp">
        </div>
      </div>
      <div class="col">
        <div class="mb-3">
          <label for="cityTo" class="form-label text-white text "><h3>Пункт прибуття <i class="bi bi-arrow-left-circle-fill text-primary"></i></h3></label>
          <input type="city" class="form-control edit" id="cityTo" aria-describedby="emailHelp">
        </div>
      </div>
    </div>
    <div class="row" id="row_number">
        <div class="col">
          <div class="mb-3">
            <label for="code" class="form-label text-white text"><h3>Номер <i class="bi bi-123 text-primary"></i></h3></label>
            <input type="text" class="form-control edit" id="code" aria-describedby="emailHelp">
          </div>
        </div>
      </div>
      <div class="row">

        <div class="col">
          <div class="mb-3">
            <div class="switch_div">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="switch">
                <label class="form-check-label" for="switch" id="switch_label"><h4>Пошук за пунктами</h4></label>
              </div>
            </div
          </div>

          <div class="mb-3" style="margin-left: 42%;">
            <button class="btn btn-lg btn-primary text-white" id="search_button"><h3>Пошук<i class="bi bi-search text-secondary"></i></h3> </button>
          </div>
        </div>

      </div>

  </div>
  </div>
</section>



</div>
<?php get_footer(); ?>
